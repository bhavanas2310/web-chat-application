import ChatPage from './components/ChatPage'

function App() {


  return (
    <>
    <ChatPage />
    </>
  )
}

export default App
